-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "04/02/2025 14:47:44"

-- 
-- Device: Altera EP4CGX15BF14C6 Package FBGA169
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEIV;
LIBRARY IEEE;
USE CYCLONEIV.CYCLONEIV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	WEEKV IS
    PORT (
	xy : OUT std_logic;
	x : IN std_logic;
	y : IN std_logic;
	F1 : OUT std_logic;
	z : IN std_logic;
	F2 : OUT std_logic;
	F4 : OUT std_logic;
	F3 : OUT std_logic;
	xpz : OUT std_logic;
	xpzp : OUT std_logic
	);
END WEEKV;

-- Design Ports Information
-- xy	=>  Location: PIN_K11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- F1	=>  Location: PIN_L4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- F2	=>  Location: PIN_N9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- F4	=>  Location: PIN_N6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- F3	=>  Location: PIN_M9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- xpz	=>  Location: PIN_L7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- xpzp	=>  Location: PIN_M13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- x	=>  Location: PIN_N13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- y	=>  Location: PIN_N10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- z	=>  Location: PIN_G13,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF WEEKV IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_xy : std_logic;
SIGNAL ww_x : std_logic;
SIGNAL ww_y : std_logic;
SIGNAL ww_F1 : std_logic;
SIGNAL ww_z : std_logic;
SIGNAL ww_F2 : std_logic;
SIGNAL ww_F4 : std_logic;
SIGNAL ww_F3 : std_logic;
SIGNAL ww_xpz : std_logic;
SIGNAL ww_xpzp : std_logic;
SIGNAL \xy~output_o\ : std_logic;
SIGNAL \F1~output_o\ : std_logic;
SIGNAL \F2~output_o\ : std_logic;
SIGNAL \F4~output_o\ : std_logic;
SIGNAL \F3~output_o\ : std_logic;
SIGNAL \xpz~output_o\ : std_logic;
SIGNAL \xpzp~output_o\ : std_logic;
SIGNAL \y~input_o\ : std_logic;
SIGNAL \x~input_o\ : std_logic;
SIGNAL \0x~0_combout\ : std_logic;
SIGNAL \z~input_o\ : std_logic;
SIGNAL \inst5~0_combout\ : std_logic;
SIGNAL \inst4~0_combout\ : std_logic;
SIGNAL \0x1~combout\ : std_logic;
SIGNAL \0x2~combout\ : std_logic;

BEGIN

xy <= ww_xy;
ww_x <= x;
ww_y <= y;
F1 <= ww_F1;
ww_z <= z;
F2 <= ww_F2;
F4 <= ww_F4;
F3 <= ww_F3;
xpz <= ww_xpz;
xpzp <= ww_xpzp;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

-- Location: IOOBUF_X33_Y11_N2
\xy~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \0x~0_combout\,
	devoe => ww_devoe,
	o => \xy~output_o\);

-- Location: IOOBUF_X8_Y0_N9
\F1~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5~0_combout\,
	devoe => ww_devoe,
	o => \F1~output_o\);

-- Location: IOOBUF_X20_Y0_N2
\F2~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5~0_combout\,
	devoe => ww_devoe,
	o => \F2~output_o\);

-- Location: IOOBUF_X12_Y0_N2
\F4~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5~0_combout\,
	devoe => ww_devoe,
	o => \F4~output_o\);

-- Location: IOOBUF_X24_Y0_N2
\F3~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst4~0_combout\,
	devoe => ww_devoe,
	o => \F3~output_o\);

-- Location: IOOBUF_X14_Y0_N2
\xpz~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \0x1~combout\,
	devoe => ww_devoe,
	o => \xpz~output_o\);

-- Location: IOOBUF_X33_Y10_N2
\xpzp~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \0x2~combout\,
	devoe => ww_devoe,
	o => \xpzp~output_o\);

-- Location: IOIBUF_X26_Y0_N8
\y~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_y,
	o => \y~input_o\);

-- Location: IOIBUF_X33_Y10_N8
\x~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_x,
	o => \x~input_o\);

-- Location: LCCOMB_X29_Y1_N0
\0x~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \0x~0_combout\ = (\y~input_o\ & \x~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \y~input_o\,
	datac => \x~input_o\,
	combout => \0x~0_combout\);

-- Location: IOIBUF_X33_Y16_N22
\z~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_z,
	o => \z~input_o\);

-- Location: LCCOMB_X29_Y1_N2
\inst5~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst5~0_combout\ = (\x~input_o\ & ((\y~input_o\))) # (!\x~input_o\ & (\z~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \z~input_o\,
	datab => \y~input_o\,
	datac => \x~input_o\,
	combout => \inst5~0_combout\);

-- Location: LCCOMB_X29_Y1_N28
\inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst4~0_combout\ = (\y~input_o\ & ((\z~input_o\) # (\x~input_o\))) # (!\y~input_o\ & ((!\x~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101111001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \z~input_o\,
	datab => \y~input_o\,
	datac => \x~input_o\,
	combout => \inst4~0_combout\);

-- Location: LCCOMB_X29_Y1_N30
\0x1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \0x1~combout\ = (\z~input_o\ & !\x~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \z~input_o\,
	datac => \x~input_o\,
	combout => \0x1~combout\);

-- Location: LCCOMB_X29_Y1_N16
\0x2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \0x2~combout\ = (!\z~input_o\ & (\y~input_o\ & \x~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \z~input_o\,
	datab => \y~input_o\,
	datac => \x~input_o\,
	combout => \0x2~combout\);

ww_xy <= \xy~output_o\;

ww_F1 <= \F1~output_o\;

ww_F2 <= \F2~output_o\;

ww_F4 <= \F4~output_o\;

ww_F3 <= \F3~output_o\;

ww_xpz <= \xpz~output_o\;

ww_xpzp <= \xpzp~output_o\;
END structure;



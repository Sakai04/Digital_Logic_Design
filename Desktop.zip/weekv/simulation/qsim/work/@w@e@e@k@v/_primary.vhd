library verilog;
use verilog.vl_types.all;
entity WEEKV is
    port(
        xy              : out    vl_logic;
        x               : in     vl_logic;
        y               : in     vl_logic;
        F1              : out    vl_logic;
        z               : in     vl_logic;
        F2              : out    vl_logic;
        F4              : out    vl_logic;
        F3              : out    vl_logic;
        xpz             : out    vl_logic;
        xpzp            : out    vl_logic
    );
end WEEKV;

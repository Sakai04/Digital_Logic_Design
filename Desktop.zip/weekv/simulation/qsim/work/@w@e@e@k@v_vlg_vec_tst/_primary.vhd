library verilog;
use verilog.vl_types.all;
entity WEEKV_vlg_vec_tst is
end WEEKV_vlg_vec_tst;

library verilog;
use verilog.vl_types.all;
entity WEEKV_vlg_check_tst is
    port(
        F1              : in     vl_logic;
        F2              : in     vl_logic;
        F3              : in     vl_logic;
        F4              : in     vl_logic;
        xpz             : in     vl_logic;
        xpzp            : in     vl_logic;
        xy              : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end WEEKV_vlg_check_tst;
